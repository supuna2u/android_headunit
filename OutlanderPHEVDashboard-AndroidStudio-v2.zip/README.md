# Outlander PHEV Dashboard — Android Studio project (prototype)

This project is a real Android app source project, not a prebuilt APK. Open the folder in Android Studio and build an APK with **Build > Build APK(s)**.

## What currently works
- Android landscape dashboard UI with animated audio-spectrum-style bars.
- Bluetooth Classic RFCOMM connection flow for paired ELM327-compatible adapters such as many Vgate models.
- Polling of standard OBD-II PIDs when supported: vehicle speed (010D), engine RPM (010C), fuel level (012F), coolant temperature (0105), control-module voltage (0142), engine load (0104).
- Connection/disconnection status and values update from OBD responses.

## First use
1. Install Android Studio and open this project folder.
2. Let Gradle sync and install the Android SDK platform 35 if prompted.
3. Build > Build APK(s). The debug APK will usually be at `app/build/outputs/apk/debug/app-debug.apk`.
4. On the phone, pair the Vgate adapter in Android Bluetooth settings first. Grant Nearby devices permission when prompted, then tap **Connect OBD** in the app.
5. Turn the ignition/vehicle to the state recommended by the adapter/car manufacturer.

## Important limitations
- Vgate sells several adapter variants. This prototype implements **Bluetooth Classic SPP**. BLE variants and Wi-Fi variants need different transport code and are not supported by this first version.
- Generic OBD-II cannot reliably provide Mitsubishi PHEV battery state/EV range, individual door states, headlight status, or TPMS pressures. Those often require Mitsubishi-specific CAN/diagnostic PIDs and a compatible adapter; those fields are deliberately marked unavailable rather than fabricated.
- The audio spectrum currently animates as a visual effect. Microphone permission is requested by the UI, but microphone-driven FFT analysis is not implemented yet. Android generally does not allow arbitrary apps to capture other apps' internal audio without special capture permissions/policies.
- No safety-critical warning should rely on this prototype. Do not operate or configure it while driving.
- The UI uses a stylized emoji vehicle placeholder rather than the generated concept-art image to keep the project self-contained.

## Build environment
Android Studio with JDK 17, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35.

## Added in this revision
- Local music playback: choose an audio file from the phone, play/pause/stop.
- Audio-reactive spectrum driven by Android's Visualizer API for music played inside this app (subject to Android/device audio-effect support).
- The audio visualizer uses `RECORD_AUDIO` permission on Android as required by Android's audio effects API.

This remains source code, not a precompiled or device-tested APK. The OBD connection currently targets Bluetooth Classic SPP. It does not yet implement Mitsubishi-specific CAN commands used by PHEV Watchdog, so battery/EV range, TPMS, headlights, and doors remain unavailable until the relevant diagnostic protocol is identified and tested.

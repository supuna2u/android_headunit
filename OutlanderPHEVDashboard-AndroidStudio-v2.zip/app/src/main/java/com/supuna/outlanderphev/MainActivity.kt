package com.supuna.outlanderphev

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.media.MediaPlayer
import android.media.audiofx.Visualizer
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.app.AlertDialog
import android.widget.Toast
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val adapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var running = false
    private var player: MediaPlayer? = null
    private var audioVisualizer: Visualizer? = null
    private val pickAudioRequest = 301
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (4 or 1024 or 4096 or 512 or 2)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/dashboard.html")
    }

    inner class Bridge {
        @JavascriptInterface fun connect() { runOnUiThread { chooseDevice() } }
        @JavascriptInterface fun disconnect() { stopObd() }
        @JavascriptInterface fun requestMicPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 201)
                else toast("Choose a music file to activate the audio-reactive visualizer")
            }
        }
        @JavascriptInterface fun chooseMusic() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(intent, pickAudioRequest)
            }
        }
        @JavascriptInterface fun toggleMusic() {
            runOnUiThread {
                val p = player
                if (p == null) { toast("Choose a music file first"); return@runOnUiThread }
                if (p.isPlaying) { p.pause(); sendJs("musicState('Paused')") }
                else { p.start(); sendJs("musicState('Playing')") }
            }
        }
        @JavascriptInterface fun stopMusic() {
            runOnUiThread {
                try { player?.stop() } catch (_: Exception) {}
                releasePlayer()
                sendJs("musicState('Stopped')")
            }
        }
    }

    private fun chooseDevice() {
        if (adapter == null) { toast("This device has no Bluetooth adapter"); return }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 200); return
        }
        if (!adapter.isEnabled) { toast("Turn on Bluetooth and pair the Vgate adapter in Android Settings first"); return }
        val devices = try { adapter.bondedDevices.toList() } catch (_: SecurityException) { emptyList() }
        if (devices.isEmpty()) { toast("Pair the Vgate adapter in Android Bluetooth settings first"); return }
        val names = devices.map { "${it.name ?: "Bluetooth device"}  •  ${it.address}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Choose your OBD-II adapter")
            .setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, names)) { _, which -> connectDevice(devices[which]) }
            .setNegativeButton("Cancel", null).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickAudioRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            startMusic(uri)
        }
    }

    private fun startMusic(uri: Uri) {
        releasePlayer()
        try {
            val p = MediaPlayer()
            p.setDataSource(this, uri)
            p.setOnPreparedListener {
                player = it
                it.start()
                attachVisualizer(it.audioSessionId)
                sendJs("musicState('Playing')")
                sendJs("trackName('Local music')")
            }
            p.setOnCompletionListener { sendJs("musicState('Finished')") }
            p.setOnErrorListener { _, _, _ -> sendJs("musicState('Playback error')"); true }
            p.prepareAsync()
            sendJs("musicState('Loading…')")
        } catch (e: Exception) {
            sendJs("musicState('Could not open audio file')")
        }
    }

    private fun attachVisualizer(sessionId: Int) {
        try {
            audioVisualizer?.release()
            val vis = Visualizer(sessionId)
            vis.captureSize = Visualizer.getCaptureSizeRange()[1]
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer, waveform: ByteArray, samplingRate: Int) {}
                override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) {
                    val values = (2 until fft.size step 2).take(32).map { i ->
                        val re = fft[i].toInt(); val im = if (i + 1 < fft.size) fft[i + 1].toInt() else 0
                        kotlin.math.sqrt((re * re + im * im).toDouble()).toInt().coerceIn(0, 255)
                    }
                    val jsArray = values.joinToString(",")
                    sendJs("audioLevels([$jsArray])")
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            vis.enabled = true
            audioVisualizer = vis
        } catch (_: Exception) {
            sendJs("musicState('Audio visualizer unavailable on this device')")
        }
    }

    private fun releasePlayer() {
        try { audioVisualizer?.enabled = false; audioVisualizer?.release() } catch (_: Exception) {}
        audioVisualizer = null
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    private fun connectDevice(device: BluetoothDevice) {
        stopObd()
        sendJs("status('Connecting to ${jsSafe(device.name ?: "Vgate")}…',false)")
        thread {
            try {
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread { toast("Allow Nearby devices permission and try again") }; return@thread
                }
                adapter?.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(spp)
                s.connect()
                socket = s; running = true
                val input = s.inputStream; val output = s.outputStream
                for (cmd in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")) {
                    writeCmd(output, cmd); readResponse(input)
                }
                sendJs("status('OBD connected • reading live data',true)")
                while (running && s.isConnected) {
                    val speed = pid(input, output, "010D")
                    val rpm = pid(input, output, "010C")
                    val fuel = pid(input, output, "012F")
                    val coolant = pid(input, output, "0105")
                    val volts = pid(input, output, "0142")
                    val load = pid(input, output, "0104")
                    val speedVal = speed?.let { it[0].toInt() } 
                    val rpmVal = rpm?.let { ((it[0].toInt() * 256) + it[1].toInt()) / 4 }
                    val fuelVal = fuel?.let { it[0].toInt() * 100 / 255 }
                    val coolantVal = coolant?.let { it[0].toInt() - 40 }
                    val voltVal = volts?.let { ((it[0].toInt() * 256) + it[1].toInt()) / 1000.0 }
                    val loadVal = load?.let { it[0].toInt() * 100 / 255 }
                    val js = "updateData(${speedVal ?: -1},${rpmVal ?: -1},${fuelVal ?: -1},${coolantVal ?: -1},${voltVal ?: -1.0},${loadVal ?: -1})"
                    sendJs(js)
                    Thread.sleep(450)
                }
            } catch (e: Exception) {
                sendJs("status('OBD connection failed: ${jsSafe(e.message ?: "check adapter type/pairing")}',false)")
            } finally {
                try { socket?.close() } catch (_: Exception) {}
                socket = null; running = false
            }
        }
    }

    private fun pid(input: InputStream, output: OutputStream, command: String): ByteArray? {
        writeCmd(output, command)
        val response = readResponse(input).replace(" ", "").replace("\r", "").replace("\n", "")
        val marker = when(command) { "010D" -> "410D"; "010C" -> "410C"; "012F" -> "412F"; "0105" -> "4105"; "0142" -> "4142"; else -> "4104" }
        val index = response.indexOf(marker)
        if (index < 0) return null
        return try {
            val hex = response.substring(index + marker.length).take(if (command == "010C" || command == "0142") 4 else 2)
            if (hex.length < 2 || hex.any { !it.isLetterOrDigit() }) null else hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        } catch (_: Exception) { null }
    }
    private fun writeCmd(out: OutputStream, cmd: String) { out.write((cmd + "\r").toByteArray()); out.flush() }
    private fun readResponse(input: InputStream): String {
        val b = StringBuilder(); val end = System.currentTimeMillis() + 1600
        while (System.currentTimeMillis() < end) {
            if (input.available() > 0) {
                val c = input.read()
                if (c < 0) break
                if (c == 62) break
                b.append(c.toChar())
            } else Thread.sleep(15)
        }
        return b.toString()
    }
    private fun stopObd() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        sendJs("status('OBD disconnected',false)")
    }
    private fun sendJs(js: String) { runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(js, null) } }
    private fun jsSafe(s: String) = s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }
    override fun onDestroy() { stopObd(); releasePlayer(); web.destroy(); super.onDestroy() }
}
